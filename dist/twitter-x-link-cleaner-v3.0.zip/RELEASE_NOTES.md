# Release Notes — Twitter/X Link Cleaner v3.0

**Release date:** 5 November 2026
**Previous version:** 2.8
**Manifest version:** 3

## Highlights

v3.0 turns a single-purpose link stripper into a configurable link cleaner. The
core behaviour is unchanged — copy a link from X and the tracking junk is gone —
but you can now choose which domain that link points at.

## New features

### Settings popup
Clicking the toolbar icon now opens a settings panel. Version 2.8 had no
interface at all; everything ran invisibly.

### Custom base domain
Choose the domain your copied links use:

- `https://x.com/...` (default, unchanged behaviour)
- `https://fixvx.com/...`, `https://fxtwitter.com/...`, `https://vxtwitter.com/...`
- Any domain you type

The field is forgiving: `fixvx` becomes `fixvx.com`, `https://fixvx.com/` is
cleaned up automatically, and `www.` is stripped. Leave it empty to keep the
original domain.

### Presets
One-click buttons fill the domain field for the common cases, plus **Original**
to return to stock behaviour.

### Live preview
A sample URL updates as you type, showing exactly what will land on your
clipboard — including which part of the URL is the replaced domain.

### On/off switch
Disable cleaning without uninstalling or disabling the extension. With the
switch off, X behaves exactly as it would without the extension.

### Settings sync
Your preferences are stored with `storage.sync`, so they follow your Firefox or
Chrome profile across devices rather than living in local storage only.

### Firefox for Android support
The manifest now declares `browser_specific_settings.gecko_android`, so the
extension is offered for Firefox for Android 142 and newer. There is no toolbar
icon on Android: the extension appears in the browser menu, and the popup is
rendered as a full-width sheet with larger touch targets.

### Extension icon
The extension previously shipped with no icon. It now has a full icon set
(16/32/48/128 px) and a toolbar button.

## Improvements

- **Wider host coverage.** Copied links are now rewritten for `x.com`,
  `twitter.com`, `www.`, `mobile.`, and `m.` hosts. Version 2.8 only matched the
  bare `x.com` and `twitter.com` hostnames, so links copied from mobile web were
  left untouched.
- **Live settings changes.** Changing a setting applies to already-open X tabs
  immediately; no page reload required.
- **Quieter console.** All the `console.log` debug chatter from 2.8 is gone. The
  extension now runs silently.
- **Copy-path regression tests.** The rewrite logic is covered by tests for
  desktop and mobile hosts; see `test-copy.js`.

## Permissions

| Permission | Why |
|---|---|
| `clipboardWrite` | Write the cleaned URL to the clipboard after X copies the original |
| `storage` | Save your base-domain and on/off preferences |

`storage` is the only permission added since 2.8. If you had 2.8 installed you
will be asked to approve it on update.

## Compatibility

- Chrome / Edge / Brave — Manifest V3
- Firefox desktop — Firefox 109 or newer
- Firefox for Android — 142 or newer
- Safari — not supported (no Manifest V3 content-script support as of this release)

## Notes for reviewers and users

- The extension runs only on `https://x.com/*` and `https://twitter.com/*`.
- No data leaves the browser. The only network activity is whatever X itself
  does; the extension never contacts the domain you configure, it only rewrites
  the copied string.
- The domain swap changes the hostname only; the path, the tracking-parameter
  stripping, and any fragment behave exactly as they did in 2.8.
- Word to the wise: third-party front-ends such as fixvx, fxtwitter, and
  vxtwitter are independent services. Choosing one sends nothing from your
  browser, but it does mean the person who opens your link visits that service
  instead of x.com.

## Known limitations

- Domains are validated before saving. A value like `localhost` is normalised to
  `localhost.com`, and invalid input falls back to the original domain rather
  than being stored.
- On mobile web, X's own "Copy link" menu item is less consistent than on
  desktop, so the copy-event handler does most of the work there.
- The popup cannot preview a real tweet; the preview uses a fixed sample URL.

## Upgrade notes

Version 3.0 keeps the same add-on ID
(`{42c11a0f-c03c-4419-8a49-e43388573e35}`), so Firefox treats it as an update to
2.8 and preserves your installation. Settings keys are new, so the first launch
after upgrading uses the defaults (cleaning on, original domain).
