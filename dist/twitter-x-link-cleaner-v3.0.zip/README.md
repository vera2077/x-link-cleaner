# Twitter/X Link Cleaner — v3.0

Strips tracking parameters (`?s=20&t=...`) from X/Twitter links copied via the **Copy Link** button, and lets you swap the base domain the link is copied with.

## What's new in 3.0

- **Popup settings menu** — click the toolbar icon to configure the extension
- **Custom base domain** — copy links as `https://fixvx.com/...`, `https://fxtwitter.com/...`, or any domain you type
- **Presets** — one click for Original / fixvx / fxtwitter / vxtwitter
- **Live preview** — see exactly what the copied link will look like
- **On/off switch** — temporarily disable cleaning without uninstalling
- **Settings sync** — stored in `chrome.storage.sync`, so they follow your browser profile

## Install (Chrome / Edge / Brave)

1. Open `chrome://extensions` (or `edge://extensions`)
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select this folder (`twitter-x-link-cleaner-plus/`)
5. Click the puzzle-piece icon and pin **Twitter/X Link Cleaner**

## Install (Firefox)

1. Open `about:debugging#/runtime/this-firefox`
2. Click **Load Temporary Add-on**
3. Select `manifest.json` in this folder
4. For permanent install, sign the zip via https://addons.mozilla.org

### Firefox for Android

The manifest declares `browser_specific_settings.gecko_android`, so AMO lists this
extension for Firefox for Android 142+. There is no toolbar icon on Android — open
the browser menu and the extension appears there, with the popup shown as a
full-width sheet.

On mobile the X web UI exposes "Copy link" less consistently than desktop, so the
`copy` event handler is the primary path there: any copied text containing an
x.com / twitter.com link is rewritten.

## Usage

Click the extension icon, then:

| Control | Effect |
|---------|--------|
| **Clean copied links** | Master switch. Off = X behaves normally. |
| **Base domain** | Type a domain such as `fixvx` or `fixvx.com`; `https://` is added automatically. Empty = keep `x.com`. |
| **Presets** | Fills the domain field instantly. |
| **Preview** | Shows the resulting URL for a sample tweet. |
| **Reset** | Restores defaults (cleaning on, original domain). |

The domain field accepts bare names (`fixvx` → `fixvx.com`), full URLs (`https://fixvx.com/`), and strips `www.`.

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | Extension metadata, permissions, popup and content-script config (MV3) |
| `content.js` | Rewrites copied links, reads settings, reacts to live changes |
| `popup.html` / `popup.css` / `popup.js` | Settings UI |
| `icons/` | Toolbar and store icons |
| `make_icons.py` | Regenerates the icons (dev only, not needed at runtime) |

## Notes

- Runs on `https://x.com/*` and `https://twitter.com/*` only
- Works on Firefox for Android (142+); the copied-link rewrites also match
  `www.`, `mobile.`, and `m.` hosts
- Permissions: `clipboardWrite` (write the clean URL), `storage` (save settings)
- Only the hostname is replaced — path, query stripping, and hashtags keep working
- Firefox may require signing for permanent installation
