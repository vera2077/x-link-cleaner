# v3.0 — Release notes (AMO field version)

Paste this into the "Release notes" box on addons.mozilla.org.

---

**New settings popup.** Click the toolbar icon to configure the extension. Version 2.8 had no interface.

**Choose your link domain.** Copied links can use `x.com` (default), `fixvx.com`, `fxtwitter.com`, `vxtwitter.com`, or any domain you type. Type `fixvx` and it becomes `fixvx.com` automatically.

**Presets and live preview.** One-click domain presets, plus a preview showing exactly what will be copied.

**On/off switch.** Disable cleaning temporarily without uninstalling.

**Settings sync.** Your preferences follow your browser profile across devices.

**Firefox for Android support (142+).** The extension now appears in the Android browser menu, with a full-width settings sheet.

**Better mobile handling.** Copied links are now cleaned for `www.`, `mobile.`, and `m.` hosts too. Previously links copied from mobile web were left untouched.

**New icon.** The extension now has a proper icon set and toolbar button.
